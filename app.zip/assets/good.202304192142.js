var s="./assets/static/good.202304192142.png";export{s as I};
